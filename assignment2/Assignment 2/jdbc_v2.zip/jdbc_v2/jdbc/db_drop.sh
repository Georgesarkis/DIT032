#!/usr/bin/env bash
dropdb mydb
