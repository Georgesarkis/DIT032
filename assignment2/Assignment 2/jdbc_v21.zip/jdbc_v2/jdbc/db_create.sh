#!/usr/bin/env bash
createdb mydb
