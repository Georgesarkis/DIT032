// MGDB1
db.plants.find().pretty()

// MGDB2
db.gardens.find().pretty()

// MGDB3
db.plants.find(
{  },  { "_id":1 }
)

// MGDB4
db.plants.find(
{ "plant.Type": "Rose" }
).pretty()

// MGDB5 
db.plants.find({}, {"plant.English_name":1, "_id":0})

// MGDB6
db.gardens.update(
{ "garden.name": "Orchid Garden" },
{ $set: { "garden.name": "Gothenburg Orchid Garden" } }
)

// MGDB7
db.gardens.find(
{ "garden.plants.roses": { $size:2 } }
)


// MGDB8
db.gardens.find(
{ "garden.plants.trees": {$exists:true}, $where:'this.garden.plants.trees.length > 1' }
)

// MGDB9
db.plants.find(
	{ $expr: 
		{ $gt: [  
			 
		 { $multiply: [ "$plant.Petal_size.Width", "$plant.Petal_size.Height" ]  },
 		0.25 ] }
} )

// MGDB10
db.gardens.aggregate ( [
	{ $lookup: { from: "plants", localField: "gardens.plants.tree", foreignField: "plants.Plants_code", as:"plant_info" } },
	{ $match: { "garden.plant_info.plant.English_name": "Maple" } },
	{ $group: {  } }
